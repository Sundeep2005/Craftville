const tempChannels = new Map();
module.exports = tempChannels;